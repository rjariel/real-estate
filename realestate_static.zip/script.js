/* ============================================================
   MOBILE NAV
   ============================================================ */
const hamburger = document.getElementById('hamburger');
const navMenu   = document.getElementById('navMenu');

hamburger?.addEventListener('click', () => {
  const open = navMenu.classList.toggle('open');
  hamburger.classList.toggle('open', open);
  hamburger.setAttribute('aria-expanded', open);
});

// Close nav on link click
navMenu?.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('open');
    hamburger.classList.remove('open');
  });
});

/* ============================================================
   ACTIVE NAV LINK ON SCROLL
   ============================================================ */
const sections  = document.querySelectorAll('section[id]');
const navLinks  = document.querySelectorAll('.nav-link');

const sectionObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const id = entry.target.getAttribute('id');
      navLinks.forEach(link => {
        link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
      });
    }
  });
}, { rootMargin: '-45% 0px -45% 0px' });

sections.forEach(s => sectionObserver.observe(s));

/* ============================================================
   PROPERTIES SLIDER
   ============================================================ */
(function initPropertySlider() {
  const track   = document.getElementById('propertiesTrack');
  const cards   = track ? Array.from(track.children) : [];
  const total   = cards.length;
  let   current = 0;

  const elCurrent = document.getElementById('propCurrent');
  const elTotal   = document.getElementById('propTotal');

  if (!track || total === 0) return;

  if (elTotal) elTotal.textContent = pad(total);

  function update() {
    if (elCurrent) elCurrent.textContent = pad(current + 1);

    // On mobile (1 column) scroll the card into view
    if (window.innerWidth <= 768) {
      cards[current].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
    }
  }

  document.getElementById('propPrev')?.addEventListener('click', () => {
    current = (current - 1 + total) % total;
    update();
  });

  document.getElementById('propNext')?.addEventListener('click', () => {
    current = (current + 1) % total;
    update();
  });
})();

/* ============================================================
   TESTIMONIALS SLIDER
   ============================================================ */
(function initTestimonialSlider() {
  const track   = document.getElementById('testimonialsTrack');
  const cards   = track ? Array.from(track.children) : [];
  const total   = cards.length;
  let   current = 0;

  const elCurrent = document.getElementById('testCurrent');
  const elTotal   = document.getElementById('testTotal');

  if (!track || total === 0) return;

  if (elTotal) elTotal.textContent = pad(total);

  function update() {
    if (elCurrent) elCurrent.textContent = pad(current + 1);

    if (window.innerWidth <= 768) {
      cards[current].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
    }
  }

  document.getElementById('testPrev')?.addEventListener('click', () => {
    current = (current - 1 + total) % total;
    update();
  });

  document.getElementById('testNext')?.addEventListener('click', () => {
    current = (current + 1) % total;
    update();
  });
})();

/* ============================================================
   SCROLL REVEAL
   ============================================================ */
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

// Add reveal class and staggered delay to cards
document.querySelectorAll(
  '.property-card, .testimonial-card, .faq-card, .feature-card'
).forEach((el, i) => {
  el.classList.add('reveal');
  const delay = (i % 4) * 80;
  el.style.transitionDelay = delay + 'ms';
  revealObserver.observe(el);
});

// Reveal section headers
document.querySelectorAll('.section-header, .hero-content, .cta-card').forEach(el => {
  el.classList.add('reveal');
  revealObserver.observe(el);
});

/* ============================================================
   HEADER SCROLL STYLE
   ============================================================ */
const header = document.getElementById('header');

window.addEventListener('scroll', () => {
  header?.classList.toggle('scrolled', window.scrollY > 60);
}, { passive: true });

/* ============================================================
   NEWSLETTER FORM
   ============================================================ */
document.querySelector('.newsletter-form')?.addEventListener('submit', e => {
  e.preventDefault();
  const input = e.target.querySelector('.newsletter-input');
  const btn   = e.target.querySelector('.newsletter-btn');
  if (!input.value.trim()) return;

  btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M3 9L7 13L15 5" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  btn.style.background = '#22c55e';
  input.value = '';
  input.placeholder = 'Thanks for subscribing!';

  setTimeout(() => {
    btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M3 9H15M15 9L10 4M15 9L10 14" stroke="white" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    btn.style.background = '';
    input.placeholder = 'Enter Your Email';
  }, 3000);
});

/* ============================================================
   HELPER
   ============================================================ */
function pad(n) {
  return String(n).padStart(2, '0');
}
